# Lunar Lite 1.0 — Android starter

Prototipo de interfaz Android hecho con Kotlin y Jetpack Compose.

## Abrir
1. Instala Android Studio en una computadora.
2. Descomprime este proyecto.
3. En Android Studio elige **Open** y selecciona la carpeta `LunarLite10`.
4. Espera a que Gradle sincronice el proyecto.
5. Conecta tu Android con depuración USB activada o usa un emulador.
6. Pulsa Run.

## Crear un APK
En Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

El APK de depuración suele aparecer en:
`app/build/outputs/apk/debug/app-debug.apk`

## Estado actual
- Pantalla principal y navegación.
- Pantalla de ajustes de rendimiento orientativos.
- Editor visual básico de capas (vista previa local).
- Opciones de HUD de demostración.
- Preferencias de interfaz.

## Límites importantes
Esta app todavía no modifica el motor ni los archivos internos de Minecraft Bedrock. Los controles de FPS son recomendaciones y la capa es una vista previa: exportación e integración real con el juego quedan para una siguiente etapa. No requiere root.
