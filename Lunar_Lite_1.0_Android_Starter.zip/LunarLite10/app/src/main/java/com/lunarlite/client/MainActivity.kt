package com.lunarlite.client

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Black = Color(0xFF090909)
private val Panel = Color(0xFF171717)
private val Panel2 = Color(0xFF222222)
private val White = Color(0xFFF5F5F5)
private val Muted = Color(0xFF9A9A9A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LunarLiteApp() }
    }
}

private enum class Page { HOME, FPS, CAPES, HUD, SETTINGS }

@Composable
fun LunarLiteApp() {
    var page by remember { mutableStateOf(Page.HOME) }
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Black, surface = Panel, primary = White,
            onPrimary = Black, onBackground = White, onSurface = White
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Black) {
            when (page) {
                Page.HOME -> HomeScreen(
                    onOpen = { page = it }
                )
                Page.FPS -> FpsScreen(onBack = { page = Page.HOME })
                Page.CAPES -> CapeScreen(onBack = { page = Page.HOME })
                Page.HUD -> HudScreen(onBack = { page = Page.HOME })
                Page.SETTINGS -> SettingsScreen(onBack = { page = Page.HOME })
            }
        }
    }
}

@Composable
private fun HomeScreen(onOpen: (Page) -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Black).padding(22.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Spacer(Modifier.height(12.dp))
        Text("LUNAR LITE", fontSize = 28.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
        Text("BEDROCK CLIENT  •  ANDROID  •  1.0", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(12.dp))
        Text("Tu Minecraft, a tu manera.", color = Muted, fontSize = 14.sp)
        val items = listOf(
            Triple("FPS BOOST", "Ajustes para aligerar la experiencia", Page.FPS),
            Triple("CAPE EDITOR", "Diseña una capa pixelada sencilla", Page.CAPES),
            Triple("HUD", "Elige qué indicadores mostrar", Page.HUD),
            Triple("SETTINGS", "Preferencias de Lunar Lite", Page.SETTINGS)
        )
        items.forEach { (title, subtitle, target) ->
            Row(
                Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp))
                    .clickable { onOpen(target) }.padding(18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text(title, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                    Text(subtitle, color = Muted, fontSize = 12.sp)
                }
                Text("›", color = Muted, fontSize = 28.sp)
            }
        }
        Spacer(Modifier.weight(1f))
        Text("LUNAR LITE 1.0  •  PROTOTIPO", color = Color(0xFF666666), fontSize = 10.sp)
    }
}

@Composable
private fun PageHeader(title: String, onBack: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        IconButton(onClick = onBack) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Volver", tint = White)
        }
        Text(title, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp, fontSize = 18.sp)
    }
}

@Composable
private fun FpsScreen(onBack: () -> Unit) {
    var lowParticles by remember { mutableStateOf(true) }
    var fancyGraphics by remember { mutableStateOf(false) }
    var smoothLighting by remember { mutableStateOf(false) }
    var renderDistance by remember { mutableStateOf(6f) }
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        PageHeader("FPS BOOST", onBack)
        Text("Ajustes recomendados", color = Muted)
        SettingSwitch("Reducir partículas", "Menos efectos visuales", lowParticles) { lowParticles = it }
        SettingSwitch("Gráficos elegantes", "Desactivar efectos gráficos avanzados", fancyGraphics) { fancyGraphics = it }
        SettingSwitch("Iluminación suave", "Desactivar para priorizar rendimiento", smoothLighting) { smoothLighting = it }
        Text("Distancia de renderizado: ${renderDistance.toInt()} chunks", fontWeight = FontWeight.Medium)
        Slider(value = renderDistance, onValueChange = { renderDistance = it }, valueRange = 4f..12f, steps = 7)
        Text("Estos controles son una guía: esta app todavía no cambia automáticamente los ajustes internos de Minecraft.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun SettingSwitch(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Muted, fontSize = 11.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun CapeScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val colors = listOf(
        Color(0xFFEEEEEE), Color(0xFF333333), Color(0xFF777777),
        Color(0xFFB7B7B7), Color(0xFF101010), Color(0xFF555555)
    )
    var selected by remember { mutableIntStateOf(0) }
    var pattern by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        PageHeader("CAPE EDITOR", onBack)
        Text("Vista previa", color = Muted)
        Box(
            Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(22.dp),
            contentAlignment = Alignment.Center
        ) {
            CapePreview(color = colors[selected], pattern = pattern)
        }
        Text("Color principal", fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            colors.forEachIndexed { index, color ->
                Box(
                    Modifier.size(38.dp).background(color, RoundedCornerShape(10.dp))
                        .clickable { selected = index },
                    contentAlignment = Alignment.Center
                ) {
                    if (selected == index) Icon(Icons.Default.Check, null, tint = if (index == 0 || index == 3) Black else White)
                }
            }
        }
        Text("Patrón", fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Liso", "Raya", "Cruz").forEachIndexed { index, label ->
                FilterChip(selected = pattern == index, onClick = { pattern = index }, label = { Text(label) })
            }
        }
        Button(
            onClick = { Toast.makeText(context, "Diseño guardado en esta vista previa (exportación pendiente).", Toast.LENGTH_LONG).show() },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = White, contentColor = Black)
        ) { Text("GUARDAR DISEÑO") }
        Text("La capa se muestra como vista previa. La exportación e integración con Minecraft se añadirán en otra versión.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun CapePreview(color: Color, pattern: Int) {
    Canvas(Modifier.width(112.dp).height(150.dp)) {
        val w = size.width
        val h = size.height
        drawRect(color = color, topLeft = Offset(w * .18f, 0f), size = androidx.compose.ui.geometry.Size(w * .64f, h))
        val accent = if (color.luminance() > .45f) Color(0xFF444444) else Color(0xFFDDDDDD)
        when (pattern) {
            1 -> drawRect(accent, topLeft = Offset(w * .43f, 0f), size = androidx.compose.ui.geometry.Size(w * .14f, h))
            2 -> {
                drawRect(accent, topLeft = Offset(w * .18f, h * .43f), size = androidx.compose.ui.geometry.Size(w * .64f, h * .14f))
                drawRect(accent, topLeft = Offset(w * .43f, 0f), size = androidx.compose.ui.geometry.Size(w * .14f, h))
            }
        }
    }
}

private fun Color.luminance(): Float = (red * 0.2126f + green * 0.7152f + blue * 0.0722f)

@Composable
private fun HudScreen(onBack: () -> Unit) {
    var fps by remember { mutableStateOf(true) }
    var coordinates by remember { mutableStateOf(true) }
    var cps by remember { mutableStateOf(false) }
    var clock by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        PageHeader("HUD", onBack)
        Text("Indicadores de pantalla", color = Muted)
        SettingSwitch("FPS", "Contador de fotogramas", fps) { fps = it }
        SettingSwitch("Coordenadas", "Posición del jugador", coordinates) { coordinates = it }
        SettingSwitch("CPS", "Clics por segundo (si es compatible)", cps) { cps = it }
        SettingSwitch("Reloj", "Mostrar hora", clock) { clock = it }
        Text("La configuración se guarda por ahora durante esta sesión. La integración con el juego se desarrollará después.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun SettingsScreen(onBack: () -> Unit) {
    var darkMode by remember { mutableStateOf(true) }
    var animations by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        PageHeader("SETTINGS", onBack)
        SettingSwitch("Tema oscuro", "Interfaz negra y gris", darkMode) { darkMode = it }
        SettingSwitch("Animaciones", "Mantener transiciones ligeras", animations) { animations = it }
        Text("Lunar Lite 1.0", fontWeight = FontWeight.Bold)
        Text("Prototipo independiente para Android. No está afiliado con Mojang ni Microsoft.", color = Muted, fontSize = 12.sp)
    }
}
